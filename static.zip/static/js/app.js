// Global variables
let simulationInterval = null;
let isSimulating = false;
let detections = [];
let maxDetections = 100;
let totalCorrect = 0;
let totalWithLabels = 0;
let truePositives = 0;   // Correctly detected attacks
let falsePositives = 0;  // Benign classified as attack
let falseNegatives = 0;  // Attacks classified as benign
let trueNegatives = 0;   // Correctly detected benign

// Chart instances
let pieChart = null;
let lineChart = null;

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    initializeCharts();
    setupEventListeners();
    updateStats();
});

// Setup event listeners
function setupEventListeners() {
    // Model selection
    document.getElementById('modelSelect').addEventListener('change', function() {
        if (isSimulating) {
            stopSimulation();
        }
    });

    // Packet rate slider
    document.getElementById('packetRate').addEventListener('input', function(e) {
        const rate = e.target.value;
        document.getElementById('rateValue').textContent = rate + ' pkt/sec';
        if (isSimulating) {
            stopSimulation();
            startSimulation();
        }
    });

    // Start simulation button
    document.getElementById('startSimulation').addEventListener('click', startSimulation);

    // Stop simulation button
    document.getElementById('stopSimulation').addEventListener('click', stopSimulation);

    // Reset stats button
    document.getElementById('resetStats').addEventListener('click', resetStats);

    // Model info button
    document.getElementById('modelInfo').addEventListener('click', showModelInfo);
}

// Initialize charts
function initializeCharts() {
    // Pie chart
    const pieCtx = document.getElementById('pieChart').getContext('2d');
    pieChart = new Chart(pieCtx, {
        type: 'doughnut',
        data: {
            labels: ['Benign', 'Attack'],
            datasets: [{
                data: [0, 0],
                backgroundColor: ['#28a745', '#dc3545'],
                borderWidth: 2,
                borderColor: '#fff'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: {
                    position: 'bottom'
                },
                title: {
                    display: false
                }
            }
        }
    });

    // Line chart
    const lineCtx = document.getElementById('lineChart').getContext('2d');
    lineChart = new Chart(lineCtx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                label: 'Benign',
                data: [],
                borderColor: '#28a745',
                backgroundColor: 'rgba(40, 167, 69, 0.1)',
                tension: 0.4,
                fill: true
            }, {
                label: 'Attack',
                data: [],
                borderColor: '#dc3545',
                backgroundColor: 'rgba(220, 53, 69, 0.1)',
                tension: 0.4,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        stepSize: 1
                    }
                },
                x: {
                    display: false
                }
            },
            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        }
    });
}

// Start simulation
function startSimulation() {
    if (isSimulating) return;
    
    isSimulating = true;
    document.getElementById('startSimulation').disabled = true;
    document.getElementById('stopSimulation').disabled = false;
    document.getElementById('modelSelect').disabled = true;
    
    // Add visual indicator
    document.querySelector('.card').classList.add('simulation-active');
    
    const rate = parseInt(document.getElementById('packetRate').value);
    // 1 second per packet at rate=1
    const interval = 1000 / rate; // Convert to milliseconds (1 second base)
    
    simulationInterval = setInterval(simulatePacket, interval);
    
    showAlert('Simulation started', 'success');
}

// Stop simulation
function stopSimulation() {
    if (!isSimulating) return;
    
    isSimulating = false;
    clearInterval(simulationInterval);
    
    document.getElementById('startSimulation').disabled = false;
    document.getElementById('stopSimulation').disabled = true;
    document.getElementById('modelSelect').disabled = false;
    
    // Remove visual indicator
    document.querySelector('.card').classList.remove('simulation-active');
    
    showAlert('Simulation stopped', 'warning');
}

// Simulate one packet at a time for real-time effect
async function simulatePacket() {
    const model = document.getElementById('modelSelect').value;
    
    try {
        const response = await fetch('/api/simulate', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                model: model,
                num_packets: 1  // One packet at a time for true real-time simulation
            })
        });
        
        if (!response.ok) {
            throw new Error('Simulation failed');
        }
        
        const data = await response.json();
        
        if (data.results && data.results.length > 0) {
            console.log('Received', data.results.length, 'packets');
            // Process all results from the batch
            data.results.forEach(result => {
                console.log('Adding detection:', result.label, 'packet#', result.packet_id);
                addDetection(result);
                
                // Show alert for attacks
                if (result.prediction === 1) {
                    showThreatAlert(result);
                }
            });
            
            updateStats(data.stats);
            console.log('Total detections in array:', detections.length);
        }
    } catch (error) {
        console.error('Simulation error:', error);
        stopSimulation();
        showAlert('Simulation error: ' + error.message, 'danger');
    }
}

// Add detection to table
function addDetection(result) {
    detections.push(result);  // Add to END to maintain order
    
    // Keep only last N detections
    if (detections.length > maxDetections) {
        detections = detections.slice(-maxDetections);  // Keep last N
    }
    
    // Update accuracy calculation and confusion matrix
    if (result.actual !== undefined) {
        totalWithLabels++;
        if (result.correct) {
            totalCorrect++;
        }
        
        // Calculate confusion matrix values
        const predicted = result.prediction;
        const actual = result.actual;
        
        if (predicted === 1 && actual === 1) {
            truePositives++;  // Attack correctly detected
        } else if (predicted === 1 && actual === 0) {
            falsePositives++;  // Benign wrongly flagged as attack
        } else if (predicted === 0 && actual === 1) {
            falseNegatives++;  // Attack missed
        } else if (predicted === 0 && actual === 0) {
            trueNegatives++;  // Benign correctly identified
        }
    }
    
    // Update table
    updateDetectionTable();
    updateCharts();
}

// Update detection table
function updateDetectionTable() {
    const tbody = document.getElementById('detectionTable');
    tbody.innerHTML = '';
    
    // Show detections in order (first packets at top)
    detections.slice(0, 50).forEach(detection => {
        const row = document.createElement('tr');
        row.className = 'detection-row-new';
        
        // Timestamp
        const time = new Date(detection.timestamp).toLocaleTimeString();
        
        // Status icon
        let statusIcon = '<i class="fas fa-question status-unknown"></i>';
        if (detection.actual !== undefined) {
            if (detection.correct) {
                statusIcon = '<i class="fas fa-check-circle status-correct"></i>';
            } else {
                statusIcon = '<i class="fas fa-times-circle status-incorrect"></i>';
            }
        }
        
        // Confidence bar
        const confidencePercent = (detection.confidence * 100).toFixed(1);
        const confidenceColor = detection.confidence > 0.9 ? 'success' : detection.confidence > 0.7 ? 'warning' : 'danger';
        
        row.innerHTML = `
            <td>${time}</td>
            <td>#${detection.packet_id}</td>
            <td><span class="badge badge-${detection.label === 'BENIGN' ? 'benign' : 'attack'}">${detection.label}</span></td>
            <td>
                <div class="d-flex align-items-center">
                    <small class="me-2">${confidencePercent}%</small>
                    <div class="progress flex-grow-1" style="height: 6px; width: 60px;">
                        <div class="progress-bar bg-${confidenceColor}" role="progressbar" style="width: ${confidencePercent}%"></div>
                    </div>
                </div>
            </td>
            <td>${detection.actual_label || '-'}</td>
            <td>${statusIcon}</td>
        `;
        
        tbody.appendChild(row);
    });
    
    document.getElementById('detectionCount').textContent = detections.length;
}

// Update statistics
function updateStats(stats) {
    if (stats) {
        document.getElementById('totalPackets').textContent = stats.total_packets.toLocaleString();
        document.getElementById('benignCount').textContent = stats.benign_count.toLocaleString();
        document.getElementById('attackCount').textContent = stats.attack_count.toLocaleString();
        
        const attackRate = stats.total_packets > 0 
            ? ((stats.attack_count / stats.total_packets) * 100).toFixed(2) 
            : 0;
        document.getElementById('attackRate').textContent = attackRate + '%';
    }
    
    // Calculate and display accuracy and metrics
    if (totalWithLabels > 0) {
        const accuracy = ((totalCorrect / totalWithLabels) * 100).toFixed(2);
        document.getElementById('accuracy').textContent = accuracy + '%';
        
        // Update confusion matrix display
        document.getElementById('truePositives').textContent = truePositives;
        document.getElementById('falsePositives').textContent = falsePositives;
        document.getElementById('falseNegatives').textContent = falseNegatives;
    } else {
        document.getElementById('accuracy').textContent = '-';
        document.getElementById('truePositives').textContent = '0';
        document.getElementById('falsePositives').textContent = '0';
        document.getElementById('falseNegatives').textContent = '0';
    }
}

// Update charts
function updateCharts() {
    // Update pie chart
    const benignCount = detections.filter(d => d.prediction === 0).length;
    const attackCount = detections.filter(d => d.prediction === 1).length;
    
    pieChart.data.datasets[0].data = [benignCount, attackCount];
    pieChart.update('none');
    
    // Update line chart (show last 20 time points)
    const maxPoints = 20;
    if (lineChart.data.labels.length >= maxPoints) {
        lineChart.data.labels.shift();
        lineChart.data.datasets[0].data.shift();
        lineChart.data.datasets[1].data.shift();
    }
    
    const timeLabel = new Date().toLocaleTimeString();
    lineChart.data.labels.push(timeLabel);
    lineChart.data.datasets[0].data.push(benignCount);
    lineChart.data.datasets[1].data.push(attackCount);
    lineChart.update('none');
}

// Show alert
function showAlert(message, type) {
    const alertArea = document.getElementById('alertArea');
    const alert = document.createElement('div');
    alert.className = `alert alert-${type} alert-dismissible fade show`;
    alert.role = 'alert';
    alert.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    alertArea.appendChild(alert);
    
    // Auto dismiss after 5 seconds
    setTimeout(() => {
        alert.remove();
    }, 5000);
}

// Show threat alert
function showThreatAlert(result) {
    const alertArea = document.getElementById('alertArea');
    const alert = document.createElement('div');
    alert.className = 'alert alert-attack alert-dismissible fade show';
    alert.role = 'alert';
    alert.innerHTML = `
        <strong><i class="fas fa-exclamation-triangle"></i> Attack Detected!</strong> 
        Packet #${result.packet_id} - Confidence: ${(result.confidence * 100).toFixed(1)}%
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    alertArea.insertBefore(alert, alertArea.firstChild);
    
    // Keep only last 3 alerts
    const alerts = alertArea.querySelectorAll('.alert');
    if (alerts.length > 3) {
        alerts[alerts.length - 1].remove();
    }
    
    // Auto dismiss after 3 seconds
    setTimeout(() => {
        alert.remove();
    }, 3000);
}

// Reset statistics
async function resetStats() {
    if (isSimulating) {
        stopSimulation();
    }
    
    try {
        const response = await fetch('/api/reset_stats', {
            method: 'POST'
        });
        
        if (response.ok) {
            detections = [];
            totalCorrect = 0;
            totalWithLabels = 0;
            truePositives = 0;
            falsePositives = 0;
            falseNegatives = 0;
            trueNegatives = 0;
            
            document.getElementById('totalPackets').textContent = '0';
            document.getElementById('benignCount').textContent = '0';
            document.getElementById('attackCount').textContent = '0';
            document.getElementById('attackRate').textContent = '0%';
            document.getElementById('accuracy').textContent = '-';
            document.getElementById('truePositives').textContent = '0';
            document.getElementById('falsePositives').textContent = '0';
            document.getElementById('falseNegatives').textContent = '0';
            document.getElementById('detectionCount').textContent = '0';
            
            document.getElementById('detectionTable').innerHTML = `
                <tr>
                    <td colspan="6" class="text-center text-muted">
                        <i class="fas fa-info-circle"></i> Start simulation to see detections
                    </td>
                </tr>
            `;
            
            // Reset charts
            pieChart.data.datasets[0].data = [0, 0];
            pieChart.update();
            
            lineChart.data.labels = [];
            lineChart.data.datasets[0].data = [];
            lineChart.data.datasets[1].data = [];
            lineChart.update();
            
            showAlert('Statistics reset successfully', 'info');
        }
    } catch (error) {
        console.error('Reset error:', error);
        showAlert('Failed to reset statistics', 'danger');
    }
}

// Show model information
async function showModelInfo() {
    const model = document.getElementById('modelSelect').value;
    const modal = new bootstrap.Modal(document.getElementById('modelInfoModal'));
    const content = document.getElementById('modelInfoContent');
    
    content.innerHTML = `
        <div class="text-center">
            <div class="spinner-border" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
        </div>
    `;
    
    modal.show();
    
    try {
        const response = await fetch(`/api/model_info/${model}`);
        
        if (!response.ok) {
            throw new Error('Failed to fetch model info');
        }
        
        const info = await response.json();
        
        let html = `
            <div class="mb-3">
                <h6><i class="fas fa-tag"></i> Model Type</h6>
                <p class="text-muted">${info.type}</p>
            </div>
        `;
        
        if (info.n_estimators) {
            html += `
                <div class="mb-3">
                    <h6><i class="fas fa-tree"></i> Number of Estimators</h6>
                    <p class="text-muted">${info.n_estimators}</p>
                </div>
            `;
        }
        
        if (info.max_depth) {
            html += `
                <div class="mb-3">
                    <h6><i class="fas fa-layer-group"></i> Max Depth</h6>
                    <p class="text-muted">${info.max_depth || 'None'}</p>
                </div>
            `;
        }
        
        if (info.top_features && info.top_features.length > 0) {
            html += `
                <div class="mb-3">
                    <h6><i class="fas fa-star"></i> Top 10 Important Features</h6>
                    <ul class="feature-list">
            `;
            
            info.top_features.forEach((feature, index) => {
                const barWidth = (feature.importance * 100).toFixed(2);
                html += `
                    <li>
                        <span class="feature-name">${index + 1}. ${feature.name}</span>
                        <span class="feature-importance">${barWidth}%</span>
                    </li>
                `;
            });
            
            html += `
                    </ul>
                </div>
            `;
        }
        
        content.innerHTML = html;
    } catch (error) {
        console.error('Model info error:', error);
        content.innerHTML = `
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle"></i> Failed to load model information
            </div>
        `;
    }
}

